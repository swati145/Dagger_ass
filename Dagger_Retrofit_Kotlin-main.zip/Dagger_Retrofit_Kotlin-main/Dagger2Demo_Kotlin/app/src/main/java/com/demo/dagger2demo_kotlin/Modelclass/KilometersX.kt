package com.demo.dagger2demo_kotlin.Modelclass

data class KilometersX(
    val estimated_diameter_max: Double,
    val estimated_diameter_min: Double
)