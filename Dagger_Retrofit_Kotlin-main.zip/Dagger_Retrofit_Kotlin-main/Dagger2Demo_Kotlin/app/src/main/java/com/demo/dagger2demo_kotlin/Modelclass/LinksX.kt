package com.demo.dagger2demo_kotlin.Modelclass

data class LinksX(
    val self: String
)