package com.demo.dagger2demo_kotlin.Modelclass

data class MissDistanceX(
    val astronomical: String,
    val kilometers: String,
    val lunar: String,
    val miles: String
)