package com.demo.dagger2demo_kotlin.Modelclass

data class MetersX(
    val estimated_diameter_max: Double,
    val estimated_diameter_min: Double
)